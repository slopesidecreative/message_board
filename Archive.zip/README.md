# my base site template

rooted in HTML5boilerplate and Dojo classwork.

(this is before adding an MVC framework)
