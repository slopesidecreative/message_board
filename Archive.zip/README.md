# message board

Associated data and CRUD functions using Mongoose, MongoDB, Express, Node. 
